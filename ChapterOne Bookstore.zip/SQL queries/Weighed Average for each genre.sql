-- something wrong here, the weighed average is not reproducing the same result
-- as in the excel csv sheet

use bookdatabase;

-- create the individual weighed averages (for Science Fiction here)

select avg(Reading_Speed)*0.2 
from books
where genre = 'Science Fiction';

select avg(Recommendation_Score)*0.4 
from books
where genre = 'Science Fiction';

select avg(Times_Read)*0.4 
from books
where genre = 'Science Fiction';

-- weighed average for 'Science Fiction'

select (
    (select avg(Reading_Speed) * 0.2 
     from books
     where genre = 'Science Fiction') +
    (select avg(Recommendation_Score) * 0.4 
     from books
     where genre = 'Science Fiction') +
    (select avg(Times_Read) * 0.4 
     from books
     where genre = 'Science Fiction')
) / 3 as final_result;

-- weighed average for all genres (with the assumption)

select genre,
       (
           (avg(19.833-Reading_Speed) * 0.2) +
           (avg(Recommendation_Score) * 0.4) +
           (avg(Times_Read) * 0.4)
       ) / 3 as final_result
from books
group by genre;


