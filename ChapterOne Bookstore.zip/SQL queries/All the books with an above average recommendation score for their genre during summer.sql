-- All the books with an above average recommendation score for their genre during summer

use bookdatabase;

-- using correlated query, to count the number of rows use select count(*) in line 7

select *
from books b
where Recommendation_Score > (
select avg(Recommendation_Score) 
from books
where genre = b.genre) and Start_Date <= '2023-08-31' and Start_Date > '2023-06-01';

-- For Science Fiction only (the others are similar):

select *
from books
where Recommendation_Score >
(select avg(Recommendation_Score)
from books
where genre='Science Fiction') and genre='Science Fiction' and Start_Date <= '2023-08-31' and Start_Date > '2023-06-01'