use bookdatabase;

-- This would work in other places, but MySQL doesn't have this built in function

select corr(Times_Read,Reading_Speed)
from books;

-- So we do this: (correlation between recommendation score and reading speed using the Pearson formula)

select (
    (sum((Recommendation_Score - avg_Recommendation_Score) * (Reading_Speed - avg_Reading_Speed))) /
    (sqrt(sum(pow(Recommendation_Score - avg_Recommendation_Score, 2))) * sqrt(sum(pow(Reading_Speed - avg_Reading_Speed, 2))))
) as correlation
from (
    select Recommendation_Score, Reading_Speed, 
           (select avg(Recommendation_Score) from books) as avg_Recommendation_Score, 
           (select avg(Reading_Speed) from books) as avg_Reading_Speed
    from books
) as subquery;

-- Now for the recommendation score and times read

select (
    (sum((Recommendation_Score - avg_Recommendation_Score) * (Times_Read - avg_Times_Read))) /
    (sqrt(sum(pow(Recommendation_Score - avg_Recommendation_Score, 2))) * sqrt(sum(pow(Times_Read - avg_Times_Read, 2))))
) as correlation
from (
    select Recommendation_Score, Times_Read, 
           (select avg(Recommendation_Score) from books) as avg_Recommendation_Score, 
           (select avg(Times_Read) from books) as avg_Times_Read
    from books
) as subquery;

-- Reading speed and Times read

select (
    (sum((Reading_Speed - avg_Reading_Speed ) * (Times_Read - avg_Times_Read))) /
    (sqrt(sum(pow(Reading_Speed  - avg_Reading_Speed , 2))) * sqrt(sum(pow(Times_Read - avg_Times_Read, 2))))
) as correlation
from (
    select Reading_Speed , Times_Read, 
           (select avg(Reading_Speed ) from books) as avg_Reading_Speed , 
           (select avg(Times_Read) from books) as avg_Times_Read
    from books
) as subquery;