install.packages("dplyr")
install.packages("ggplot2")

library("dplyr")
library("ggplot2")

file <- read.csv(file.choose())  # from here, search for the file in your computer

View(file)

# distribution of recommendation scores, it's for testing purposes it's not useful for anything

ggplot(file, aes(x = Recommendation.Score)) +
  geom_histogram(binwidth = 1, fill = "blue", color = "black") +
  labs(title = "Distribution of Recommendation Scores", x = "Recommendation Score", y = "Count")+
  annotate("text", x=8 ,y=10 , label="Greatest", color="black",size=3, angle=0)+
  annotate("text", x=8 ,y=9 , label="Value", color="black",size=3, angle=0)


# get the average recommendation score

a_r <- file %>%
  group_by(Genre) %>%
  summarise(Average_Recommendation = mean(Recommendation.Score))

# get the average times read

a_tr <- file %>%
  group_by(Genre) %>%
  summarise(Average_times_read = mean(Times.Read))

# whichever one is largest shall appear in green, and others will be in blue

a_r$color <- ifelse(a_r$Average_Recommendation == max(a_r$Average_Recommendation), "green", "blue")

a_tr$color <- ifelse(a_tr$Average_times_read == max(a_tr$Average_times_read), "green", "blue")

# Plot the bar chart about the greatest average recommendation score

ggplot(a_r, aes(x = Genre, y = Average_Recommendation, fill = color)) +
  geom_bar(stat = "identity") +
  scale_fill_identity() +
  labs(title = "Average Recommendation vs Genre", x = "Genre", y = "Average Recommendation") +
  theme_minimal() +
  annotate("text", x=2 ,y=0.75 , label = "Greatest Score", color = "black", size = 3, angle = 0)

# Plot the bar chart about the greatest average times read

ggplot(a_tr, aes(x = Genre, y = Average_times_read, fill = color)) +
  geom_bar(stat = "identity") +
  scale_fill_identity() +
  labs(title = "Average of Times Read vs Genre", x = "Genre", y = "Average Times Read") +
  theme_minimal() +
  annotate("text", x=2 ,y=0.75 , label = "Greatest Score", color = "black", size = 3, angle = 0)
